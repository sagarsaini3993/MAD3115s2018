//
//  ViewController.swift
//  Navigation Drawer
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewToSlide: UIView!
    @IBAction func btnAction(_ sender: UIButton) {
        
        
        
        if self.viewToSlide.frame.origin.x == CGFloat(-250) {
            UIView.animate(withDuration: 0.4, delay: 0.0, options: UIViewAnimationOptions.curveEaseInOut, animations: {
                self.viewToSlide.frame.origin.x = 0
            }, completion: nil)
        } else {
            UIView.animate(withDuration: 0.4, delay: 0.0, options: UIViewAnimationOptions.curveEaseInOut, animations: {
                self.viewToSlide.frame.origin.x = -250
            }, completion: nil)
        }
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

