//
//  SignUpVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtContactNumber: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtPostalCode: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var segGender: UISegmentedControl!
    @IBOutlet weak var pickDOB: UIDatePicker!
    @IBOutlet weak var pickCity: UIPickerView!
    
    //MARk:- Variables
    
    var cityList : [String] = ["Toronto", "Vancouver", "Edmenton", "Brampton", "Jasper", "Ottawa", "Calgery", "Banff"]
    var selectedCityIndex : Int = 0
    var gender : String = ""
    //MARK:- Button Actions
    
    @objc func btnSubmit() {
        
        var data : String = txtName.text!
        data += "\n" + txtContactNumber.text!
        data += "\n" + txtAddress.text!
        data += "\n" + txtPostalCode.text!
        data += "\n" + txtEmail.text!
        data += "\n" + txtPassword.text!
        data += "\n" + txtConfirmPassword.text!
        data += "\n  \(pickDOB.date)"
        
        selectedCityIndex = pickCity.selectedRow(inComponent: 0)
        data += "\n" + cityList[selectedCityIndex]
        
        switch segGender.selectedSegmentIndex {
        case 0:
            data += "\n Male"
            gender = "Male"
        case 1:
            data += "\n Female"
            gender = "Female"
        case 2:
            data += "\n No Disclosure"
            gender = "No Disclosure"
        default:
            data += "\n No Disclosure"
        }
        
        let infoAlert = UIAlertController(title: "Confirm details", message: data, preferredStyle: UIAlertControllerStyle.alert)
        
        if txtPassword.text != txtConfirmPassword.text {
            infoAlert.message = "Both passwords must be same"
        } else {
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default, handler: {_ in self.displayHomeVC()}))
        }
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        pickCity.dataSource = self
//        pickCity.delegate = self

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: true)
        self.title = "Sign Up"
        
        let btnDone = UIBarButtonItem(title: "Submit", style: UIBarButtonItemStyle.plain, target: self, action: #selector(btnSubmit))
        self.navigationItem.rightBarButtonItem = btnDone
    }
    
    //MARK:- Picker View
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cityList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return cityList[row]
    }
    
    func displayHomeVC() {
        let newUser = User(txtName.text!, txtAddress.text!, txtContactNumber.text!, txtPostalCode.text!, cityList[pickCity.selectedRow(inComponent: 0)], txtEmail.text!, txtPassword.text!, self.gender, pickDOB.date)
        
        if User.addUser(newUser: newUser) {
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
            navigationController?.pushViewController(homeVC, animated: true)
        } else {
            let infoAlert = UIAlertController(title: "Unsuccessful", message: "Account creation unsuccessful", preferredStyle: UIAlertControllerStyle.alert)
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
        
        
    }

}
