//
//  HomeVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        displayUsers()
        // Do any additional setup after loading the view.
    }
    
    func displayUsers() {
        var userList = User.getAllUsers()
        
        for user in userList.values{
            print("Name : \(user.name)")
            print("Email : \(user.email)")
            print("Date of Birth \(user.dob)")
            print("City \(user.city)")
            
        }
    }

}
